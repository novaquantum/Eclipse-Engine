Intersect Contributors
============================================

* **[Robert Lodico](https://github.com/lodicolo)**

  * Bug fixes, general support and counsel.
  * Likely our new network expert - too soon to tell.

