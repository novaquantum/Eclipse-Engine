Intersect Authors
============================================

* **[JC Snider](https://github.com/jcsnider)**
* **[Joe Bridges](https://github.com/irokaiser)**

