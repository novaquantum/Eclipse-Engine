Title: Eclipse Origins v2 Free MMORPG Maker
Description: <b>Purpose:</b> Open-source game engine used to create your very own MMORPG!
<br /><br />
<b>Provided:</b> Fantastic base with everything you need for making an MMORPG! There's even a huge community based solely around using this software which is filled with documentation, tutorials and resources. Please keep in mind that the provided source code requires your average VB6 runtime files installed as well as the VB6 DX7 library. These can be found as a separate download on the website.
<br /><br />
<b>Support:</b> I'll offer what support I can on this site, but for tutorials and resources please visit the website.
<br /><br />
<b>Website:</b> <a href="http://www.freemmorpgmaker.com">Free MMORPG Maker</a>
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=73749&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
