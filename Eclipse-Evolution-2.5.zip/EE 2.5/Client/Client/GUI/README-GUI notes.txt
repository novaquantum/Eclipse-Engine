GUI notes; Keep these in mind. -EE Devs
-800x600 GUI is actually 805x600. Display had to be extended to avoid cutting off the map.
-CUSTOM does not change anything - it's just a handy folder for custom menu images.